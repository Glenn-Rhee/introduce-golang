# @srios000/golit-6

## 0.0.1

### Initial Commit
- golang & lit element integration