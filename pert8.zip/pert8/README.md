# LitElement JavaScript starter

This project provides a sample login component built using LitElement with JavaScript.

## Serve using Go Server

This project uses a Go server to serve the application. To start the Go server, run the following command:

```go
go run main.go
```

## More information

See [Get started](https://lit.dev/docs/getting-started/) on the Lit site for more information.
